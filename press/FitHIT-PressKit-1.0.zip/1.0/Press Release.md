FOR IMMEDIATE RELEASE 

FitHIT for iPhone - the best looking interval fitness app.

Dublin, Ireland — December 10th 2013 — Appuchino is proud to announce the release of their health and fitness application FitHIT for iPhone to the iTunes App Store. 

FitHIT is an intuitive and stylish app designed to help fitness fans personalize, time and log their workouts. At its core, FitHIT is an interval timer and workout logger with a sleek interface designed exclusively for iOS 7. The app was specifically designed for people doing CrossFit®, HIIT, Tabata and other types of interval fitness training.

Alexey Rashevskiy, CEO of Appuchino said "We're really delighted to launch FitHIT to the market today. Keeping fit is a personal passion of mine, and what's great about this app, is it's so easy to use and super flexible. You can create and keep track of almost any workout you like. We kept the interface very simple and color driven so that fitness fans can just concentrate on having a great workout." 

Some of the major benefits of the application have to do with your ability to create complicated workouts, like AMRAP workouts. Once you've input the specifics of your workout, the app will keep track of your progress as it's happening. At the end of the workout you'll also have stats regarding how many rounds you completed, detailed timing information for each exercise and more.

## FitHIT Features 
- A sleek, easy-to-use graphical user interface that has been designed with iOS 7 in mind. 
- Six built-in workouts for users to choose from 
- Color-driven visual timer gives users more time to focus on working out 
- Build any workout and specify information like number of sets, number of reps or fixed time 
- Track progress using FitHIT's log of workout activity, both high level and detailed logs 
- Multiple alert options (including sound, vibration and voice) to alert users about their next exercise

## Pricing and Availability
FitHIT is available for download on the App Store May 6, 2014 at the special price of $1.99/1,99 €/£1.49. It is designed exclusively for iPhone and iPod Touch with iOS 7 on board.

App Store Link: https://itunes.apple.com/us/app/fithit-interval-timer-workout/id852665829
Website Link: http://fithit.co
Press Kit Link: http://fithit.co/press/FitHIT-PressKit-1.0.zip

## Promo Codes for Media
A limited number of promo codes are available to members of the media. Journalists interested in receiving one should contact Appuchino - info@appuchino.ie.

## About Appuchino
Appuchino is a small app development company based in Dublin, Ireland. 
As well as FitHIT we make Colorific - drawing and coloring book for iPad used by more than 500,000 children around the world (http://colorificapp.com). 

For more information about FitHIT or any of our other apps, please contact info@appuchino.ie.

## Press Contact
Email: info@appuchino.ie
Twitter: @Appuchino
Website: http://appuchino.ie