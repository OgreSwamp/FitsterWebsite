FOR IMMEDIATE RELEASE 

FitHIT for iPhone - an interval timer and workout logger for iPhone that's  slick, cool and really easy to use. Stay cool while you sweat!

May 1, 2014 -- Appuchino is proud to announce the release of their health and fitness application FitHIT for iPhone to the iTunes App Store. 

FitHIT is an intuitive and stylish app designed to help fitness fans personalize, time and log their workouts. At its core, FitHIT is an interval timer and workout logger with a sleek interface designed exclusively for iOS 7. Alexey Rashevskiy, CEO of Appuchino said "We’re really delighted to launch FitHIT to the market today. Keeping fit is a personal passion of mine, and what’s great about this app, is it’s so easy to use and super flexible. You can create and keep track of almost any workout you like. We kept the interface very simple and color driven so that fitness fans can just concentrate on having a great workout."
 

## FitHIT Features 
- A sleek, easy-to-use graphical user interface that has been designed with iOS 7 in mind. 
- Six built-in workouts for users to choose from 
- Color-driven visual timer gives users more time to focus on working out 
- Build any workout and specify information like number of sets, number of reps or fixed time 
- Track progress using FitHIT's log of workout activity, both high level and detailed logs 
- Multiple alert options (including sound, vibration and voice) to alert users about their next exercise

## Pricing and Availability
FitHIT is available for download on the App Store May 1, 2014 at the special price of $1.99/1,99 €/£1.49. It is designed exclusively for iPhone and iPod Touch with iOS 7 on board.

App Store Link: http://appstore.com/fithit
Website Link: http://fithit.co

## Promo Codes for Media


## About Appuchino
Appuchino is an app development company based in Dublin, Ireland. For more information about FitHIT or any of our other apps, please contact info@appuchino.ie.